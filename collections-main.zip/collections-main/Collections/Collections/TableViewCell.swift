//
//  TableViewCell.swift
//  Collections
//
//  Created by Антон Заверуха on 17.07.2022.
//  Copyright © 2022 Антон Заверуха. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {
    @IBOutlet weak var collectionsLabel: UILabel!
}
