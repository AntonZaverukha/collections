//
//  ArrayContacts.swift
//  Collections
//
//  Created by Антон Заверуха on 22.07.2022.
//  Copyright © 2022 Антон Заверуха. All rights reserved.
//

import Foundation

struct ArrayContacts {
    var name: String
    var phone: String
}
